function plotMarkerSize = getPlotMarkerSize()

plotMarkerSize = 7;